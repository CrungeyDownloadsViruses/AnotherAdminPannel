xterm -hold -fg white -bg black -e "cd ftp; node init.js"
$SHELL
