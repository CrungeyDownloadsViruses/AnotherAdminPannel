const PASSWORD = "mysecretpassword"; // must match backend
const consoleOutput = document.getElementById("console-output");
const consoleInput = document.getElementById("console-input");
const ramBar = document.getElementById("ram-bar");
const cpuBar = document.getElementById("cpu-bar");
const ramLabel = document.getElementById("ram-percent");
const cpuLabel = document.getElementById("cpu-percent");

async function updateUsage() {
  try {
    // --- RAM ---
    const ramRes = await fetch("/ram-usage");
    const ram = await ramRes.json();
    const ramPercent = Math.min(100, (ram.usedRAM / ram.totalRAM) * 100);

    setBar(ramBar, ramLabel, ramPercent);

    // --- CPU ---
    const cpuRes = await fetch("/cpu-usage");
    const cpu = await cpuRes.json();
    const cpuPercent = Math.min(100, cpu.calculatedCpuUsage);

    setBar(cpuBar, cpuLabel, cpuPercent);

  } catch (e) {
    console.error("Usage fetch error:", e);
  }
}

function setBar(bar, label, percent) {
  // Set the bar height (bottom-up)
  bar.style.width = `${percent}%`;

  // Compute bar color: green → red
  const red = Math.round((percent / 100) * 255);
  const green = Math.round(255 - (percent / 100) * 255);
  bar.style.backgroundColor = `rgb(${red},${green},0)`;

  // Update label text and invert color for readability
  if (label) {
    label.textContent = `${percent.toFixed(1)}%`;
    const invRed = 255 - red;
    const invGreen = 255 - green;
    label.style.color = `rgb(${invRed},${invGreen},0)`;
  }
}

// Initial call
updateUsage();

// Update every second
setInterval(updateUsage, 1000);


// WebSocket console
const ws = new WebSocket(`ws://${location.host}`);
ws.onmessage = (event) => {
  const msg = JSON.parse(event.data);
  if (msg.type === "console") {
    consoleOutput.textContent += msg.data;
    consoleOutput.scrollTop = consoleOutput.scrollHeight;
  }
};

consoleInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && consoleInput.value.trim()) {
    ws.send(consoleInput.value.trim());
    consoleInput.value = "";
  }
});

// Server control buttons
document.getElementById("start-btn").onclick = async () =>
  await fetch("/terminal?cmd=start");

document.getElementById("stop-btn").onclick = async () =>
  await fetch("/terminal?cmd=stop");

document.getElementById("restart-btn").onclick = async () => {
  await fetch("/terminal?cmd=stop");
  setTimeout(() => fetch("/terminal?cmd=start"), 2000);
};

// File browser
async function loadFiles() {
  try {
    const res = await fetch("/files", {
      headers: { "X-Password": PASSWORD },
    });
    const files = await res.json();
    renderFiles(files);
  } catch (err) {
    console.error("File load error:", err);
  }
}

function renderFiles(files) {
  const list = document.getElementById("file-list");
  list.innerHTML = "";
  files.forEach((f) => {
    const el = document.createElement("div");
    el.className = "file-item";
    el.textContent = `${f.name} (${f.isDirectory ? "dir" : f.size + "b"})`;
    const delBtn = document.createElement("button");
    delBtn.textContent = "Delete";
    delBtn.onclick = async () => {
      await fetch(`/files/${f.name}`, {
        method: "DELETE",
        headers: { "X-Password": PASSWORD },
      });
      loadFiles();
    };
    const dlBtn = document.createElement("button");
    dlBtn.textContent = "Download";
    dlBtn.onclick = () =>
      window.open(`/files/download/${f.name}`, "_blank");
    el.append(" ", dlBtn, " ", delBtn);
    list.appendChild(el);
  });
}

document.getElementById("upload-btn").onclick = async () => {
  const fileInput = document.getElementById("file-upload");
  const file = fileInput.files[0];
  if (!file) return alert("No file selected");
  const form = new FormData();
  form.append("file", file);
  await fetch("/files/upload", {
    method: "POST",
    headers: { "X-Password": PASSWORD },
    body: form,
  });
  fileInput.value = "";
  loadFiles();
};

document.getElementById("create-btn").onclick = async () => {
  const name = document.getElementById("new-file-name").value.trim();
  if (!name) return alert("Enter file name");
  await fetch("/files/new", {
    method: "POST",
    headers: {
      "X-Password": PASSWORD,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ name }),
  });
  document.getElementById("new-file-name").value = "";
  loadFiles();
};

loadFiles();
